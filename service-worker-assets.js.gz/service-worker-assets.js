﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-SO\/fuIIWUxoIu1OABrOpK5n\/AvzxJcg+0H3PT1eutAE=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-YLGeXaapI0\/5IgZopewRJcFXomhRMlYYjugPLSyNjTY=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-s\/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-pFFlN5QT\/RJOc4HiHMREul9u4Sr2zkluTki1Gci1bwA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-jv\/FE11GNZ4CCTcR+iPeH1ka3xt+a4+pwymGAetih9k=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-4Yh4OTT5TEAPNyXEzOG+n5l2HPK294WFItz4SIelj88=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-2OdnPsDgJyoSaSlvebGMRd2MxC+4UIqparqVrQZAFDE=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-YXYNlLeMqRPFVpY2KSDhleLkNk35d9KvzzwwKAoiftc=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-cUOztblhuGlkjvgM72ql0e2NRuVqwW32qti8huxzYXs=",
      "url": "_framework\/dotnet.5.0.8.js"
    },
    {
      "hash": "sha256-mG0NvdLRlAoGcR371Pt9MnGNVjLwkpgXKkFOGf2uRJI=",
      "url": "IndexedDb.styles.css"
    },
    {
      "hash": "sha256-LGXN\/g0va7bm\/ezE+vcQCxERPV\/biFlibfTVqhT2+B4=",
      "url": "_content\/TG.Blazor.IndexedDB\/indexedDb.Blazor.js"
    },
    {
      "hash": "sha256-87GSJ2s2OMkisqXfFiDAxZvfWTqKjH+q3RK5zqPWx\/8=",
      "url": "_framework\/Blazor.IndexedDB.WebAssembly.dll"
    },
    {
      "hash": "sha256-9o1gmRT9v5CdEiyzetqF3nQ8r4zjiX7bcVrZ9f1o2mU=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-7NBYsyleDnuhkYPaw7qeBGtclrBR7VNAdInln9ZBe5o=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-pUUykxBp+Q+jpt5d2o++CWi+KX6k0owddZdqOu4a+qc=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-y2gsiOao6UQ\/fAvZnYlyilQtFAzylYEAH0TEjXXtDdM=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-bZZ69\/58+BnN9G33FpTd2iXAdfgLbBnDUiiKxfaZ7IU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-7mxFRRlriJzO95ZBz4cmDSFADogdaoDy8MxzQoNtwaU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-cwzKuqTaJjYc5QXknt6NaBt\/MWSt9DYHfmu0I\/CV2mc=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-bqAmv+2te1foBbCZP6+QwNa+Ej9GVKQRvn\/O1lINe2k=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-p\/wbqVzUSluzI4XwK4szO47dKHczuTYGOjBLANcjrcA=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-SozZnCb38JE0AZkWYzjZ0ZSZx5WGRjD2xu0lZYPuoL0=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-OsmdQoFiNmpqW0WHVklQ4R5\/fLVeqFPmPBRQzZxxufQ=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-g1C9Fnh++M4k1mLduCz2yUnf\/70tTCbdZ\/s6bDjsmZM=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-32yXMbcCMbfUq7vtlIPput8uO7SZK8E9m3V8EXMScBc=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-OnkE8PpnMnXIehQSoM3YCoDTrl5sZqu04osgcbEL6Qc=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-E1ZVZc8ppcbuan9B4K4NDw+BijA0pjKkIIwlnGerx9g=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-CETD5tkXtiKEgbXyN\/lp0Ejf6LcHIhgeQIEyow2mhmY=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-2Ggw5bu\/GTo513InJacU+vwv8+tGIbqHAsM\/1NaM8G0=",
      "url": "_framework\/TG.Blazor.IndexedDB.dll"
    },
    {
      "hash": "sha256-lMz0eyBNUzN4u4WXBdqnG\/Xmbi+uds7k760\/W3uDqiM=",
      "url": "_framework\/IndexedDb.dll"
    },
    {
      "hash": "sha256-vQfofKvIxTLhvbXaorurVn3miv9vVQ3j65P33aaSCvM=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-VkLGXCctXqC552tUEDndBZ5fgrRiMk7JRkDQHJSUaAk=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-hBebAb9lQMdKxDvelVzRKB\/5C1dNzuvBn+z8FexDtt4=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-lZMx6Fo0lQVkk46qNT+lTMrcUyqWiqGpxSaIFoZ8vac=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-9gIC91MvqJQWE5FD3VUoPDsMUp+8GQ6RTOfQOQ8eGt8=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-1+4DmG2IHxlpIwtnEao\/OCxXRhr1AtL3UX9HtElya00=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-cjUZGbFkKt4L94nxCN9jA9sIkh635jdhU31Hbzq8KNs=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-Sepd3DnUoxRyvOe8Qxo54iqNymMfhHuFWejQ\/Vqiq88=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-Ctf4X4pgsg+RezGyNgCmIedr9Lmp\/9\/3fr3de7bk9i8=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-rpmdQaL0SZVXWPiknBkn67sugL\/145Y2OhsTMK2wJxQ=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-5BFDuepoc5uv6FkTUB\/gtSQDzUv4y8glKQjTenIPVlc=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-Wn9pDuRlH9sUkcr3IH0ssfOawhCjFl3JwH6Vv1A2xxE=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-ZzXi9VB4sMH+6alHnoBpNMx8fGuNzOTyJisoquWNAhs=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-ufh2TXUbye+Tkif0G9Ap5\/sQrhiaMZMEpX2qxsc28wE=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-Z1yMZz2ycW1X4tP6CL8TNrm6X7qsqbhpeACoTX0U1dk=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-pDQI1Mnow4Ia95PRbyUisFExBENcocyqWRVXw7ef\/3M=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-vKgwur\/29xXCchx3kjPSrG0jlHOLXL071iAlYqJHr4M=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-3KK2d2uBGd7oSNYIoTk+zMT\/v9Jz99PbyxTQZv2kNZg=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-gWkzGSN4zPZBt5jc9M7vFcY8FAyrQX730zYd8sM\/zHY=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-dw+MW5vy+3W8yDus4V0nrm3ESzDO3yCq0T\/j+ANKcqI=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-7oYDPzYkszkGsej0JsrKWpMArRZ2A8DNE3TUqUPT578=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-DV5uvNkGja00dqXskwZxYak23o0NuvXxYA3H1R38JkI=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-eQogcSBx1pelpxqJo4DoCa5ARozyXvakxfnp3DIr1I8=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-SgrIA9\/ipoWnWWtMihsGbOaorCILCs7J34GJ+5G25LY=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-BBpppG24szI5K3Kj6gY2wUvKCcM1mL21Y40U1LojJDE=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-aUUhSORllrlw6mUXuKFR72wUPfryKu60ogDqZUdBukM=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "jGP9I0Vg"
};
